// include.h
// Centralized includes for randomDNDclass.cpp

#ifndef INCLUDE_H
#define INCLUDE_H

#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <json/json.h> // Requires JsonCpp library

#endif // INCLUDE_H
